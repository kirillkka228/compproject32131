using System.Globalization;
using System.Text.RegularExpressions;

namespace PoiasnyNMT;

/// <summary>Перевірки, які виконує КОД, а не ШІ: приватність, відповідь, витік відповіді, цитати.</summary>
public static class Guards
{
    private static readonly Regex NumberRx = new(@"-?\d+(?:[.,]\d+)?", RegexOptions.Compiled);
    private static readonly Regex AnswerRx = new(
        @"^\s*(?:[xхXХ]\s*=\s*)?(-?\d+(?:[.,]\d+)?)\s*(?:грн|см)?\.?\s*$", RegexOptions.Compiled);
    private static readonly Regex EmailRx = new(@"[\w.+-]+@[\w-]+\.[\w.-]+", RegexOptions.Compiled);
    private static readonly Regex PhoneRx = new(@"\+?\d[\d\s\-()]{8,}\d", RegexOptions.Compiled);

    /// <summary>Прибирає e-mail і телефони перед відправкою тексту в ШІ.</summary>
    public static string ScrubPersonalData(string text)
    {
        text = EmailRx.Replace(text, "[приховано]");
        return PhoneRx.Replace(text, "[приховано]");
    }

    /// <summary>Якщо учень увів саме число — повертає його; інакше null (це запитання, а не відповідь).</summary>
    public static decimal? TryParseAnswer(string input)
    {
        var m = AnswerRx.Match(Normalize(input));
        return m.Success ? ParseDecimal(m.Groups[1].Value) : null;
    }

    /// <summary>Чи містить репліка ШІ число, яке не можна видавати (відповідь задачі).</summary>
    public static bool LeaksAnswer(string reply, decimal[] forbidden)
    {
        foreach (Match m in NumberRx.Matches(Normalize(reply)))
        {
            var v = ParseDecimal(m.Value);
            if (v == null) continue;
            if (forbidden.Any(f => f == v.Value || f == -v.Value)) return true;
        }
        return false;
    }

    /// <summary>Чи справді учень таке писав (захист від вигаданих моделлю «цитат»).</summary>
    public static bool IsRealQuote(string quote, string studentText)
    {
        var q = Squash(quote);
        return q.Length >= 3 && Squash(studentText).Contains(q);
    }

    private static string Squash(string s) =>
        Regex.Replace(s.ToLowerInvariant(), @"\s+", " ").Trim(' ', '"', '«', '»', '.', '…');

    private static string Normalize(string s) => s.Replace('−', '-').Replace('–', '-');

    private static decimal? ParseDecimal(string s) =>
        decimal.TryParse(s.Replace(',', '.'), NumberStyles.Number, CultureInfo.InvariantCulture, out var d) ? d : null;
}
