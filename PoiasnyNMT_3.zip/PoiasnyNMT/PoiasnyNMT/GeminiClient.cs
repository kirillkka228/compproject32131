using System.Text;
using System.Text.Json;

namespace PoiasnyNMT;

/// <summary>Одна репліка діалогу. Role: "user" (учень) або "model" (ШІ).</summary>
public record ChatTurn(string Role, string Text);

/// <summary>Мінімальний клієнт Google Gemini API (REST, generateContent).</summary>
public sealed class GeminiClient
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(60) };
    private readonly string _apiKey;
    private readonly string _model;

    public GeminiClient(string apiKey, string model)
    {
        _apiKey = apiKey;
        _model = model;
    }

    public string Model => _model;

    public async Task<string> AskAsync(string systemPrompt, IEnumerable<ChatTurn> history,
                                       bool json = false, double temperature = 0.7)
    {
        var body = new Dictionary<string, object>
        {
            ["systemInstruction"] = new { parts = new[] { new { text = systemPrompt } } },
            ["contents"] = history.Select(t => new
            {
                role = t.Role,
                parts = new[] { new { text = t.Text } }
            }).ToArray(),
            ["generationConfig"] = json
                ? new Dictionary<string, object> { ["temperature"] = temperature, ["responseMimeType"] = "application/json" }
                : new Dictionary<string, object> { ["temperature"] = temperature }
        };

        var url = $"https://generativelanguage.googleapis.com/v1beta/models/{_model}:generateContent";
        using var req = new HttpRequestMessage(HttpMethod.Post, url);
        req.Headers.Add("x-goog-api-key", _apiKey);
        req.Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");

        using var resp = await Http.SendAsync(req);
        var text = await resp.Content.ReadAsStringAsync();
        if (!resp.IsSuccessStatusCode)
            throw new InvalidOperationException($"Gemini API повернув помилку {(int)resp.StatusCode}: {Shorten(text)}");

        using var doc = JsonDocument.Parse(text);
        if (!doc.RootElement.TryGetProperty("candidates", out var cands) || cands.GetArrayLength() == 0)
            throw new InvalidOperationException("Модель не повернула відповіді (можливо, запит заблоковано фільтром).");

        var sb = new StringBuilder();
        if (cands[0].TryGetProperty("content", out var content) &&
            content.TryGetProperty("parts", out var parts))
        {
            foreach (var p in parts.EnumerateArray())
                if (p.TryGetProperty("text", out var t)) sb.Append(t.GetString());
        }
        if (sb.Length == 0)
            throw new InvalidOperationException("Модель повернула порожню відповідь.");
        return sb.ToString().Trim();
    }

    private static string Shorten(string s) => s.Length <= 400 ? s : s[..400] + "…";
}
