using System.Text;
using System.Text.Json;

namespace PoiasnyNMT;

[System.ComponentModel.DesignerCategory("Code")]
public class MainForm : Form
{
    private enum Mode { Idle, Teaching, Control }

    // --- елементи інтерфейсу ---
    private readonly ComboBox _cmbTopic = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly Button _btnStart = new() { Text = "1. Почати урок для Петрика" };
    private readonly Button _btnFinish = new() { Text = "2. Завершити урок → розбір", Enabled = false };
    private readonly Button _btnControl = new() { Text = "3. Контрольна задача", Enabled = false };
    private readonly Label _lblStatus = new() { AutoSize = false, ForeColor = Color.DimGray };
    private readonly RichTextBox _chat = new() { ReadOnly = true, BackColor = Color.White, BorderStyle = BorderStyle.None };
    private readonly RichTextBox _report = new() { ReadOnly = true, BackColor = Color.FromArgb(250, 250, 245), BorderStyle = BorderStyle.None };
    private readonly TextBox _txtInput = new() { Multiline = true, Enabled = false };
    private readonly Button _btnSend = new() { Text = "Надіслати", Enabled = false };

    // --- стан ---
    private readonly Random _rnd = new();
    private GeminiClient? _ai;
    private Mode _mode = Mode.Idle;
    private TopicCard _card = Topics.All[0];
    private readonly List<ChatTurn> _history = new();      // діалог з Петриком
    private readonly List<string> _studentTexts = new();   // лише репліки учня (для розбору)
    private readonly List<ChatTurn> _hintHistory = new();  // діалог підказок до задачі
    private ControlTask? _task;
    private bool _busy;

    public MainForm()
    {
        Text = "Поясни Петрику — підготовка до НМТ з математики";
        Font = new Font("Segoe UI", 10f);
        MinimumSize = new Size(1100, 650);
        Size = new Size(1250, 760);
        StartPosition = FormStartPosition.CenterScreen;

        BuildLayout();

        foreach (var t in Topics.All) _cmbTopic.Items.Add(t.Title);
        _cmbTopic.SelectedIndex = 0;

        _btnStart.Click += (_, _) => StartLesson();
        _btnFinish.Click += async (_, _) => await FinishLessonAsync();
        _btnControl.Click += (_, _) => StartControlTask();
        _btnSend.Click += async (_, _) => await SendAsync();
        _txtInput.KeyDown += async (_, e) =>
        {
            if (e.KeyCode == Keys.Enter && !e.Shift)
            {
                e.SuppressKeyPress = true;
                await SendAsync();
            }
        };

        InitAi();
    }

    // ------------------------------------------------------------------ UI

    private void BuildLayout()
    {
        var left = new Panel { Dock = DockStyle.Left, Width = 290, Padding = new Padding(12), BackColor = Color.FromArgb(240, 244, 250) };
        var right = new Panel { Dock = DockStyle.Right, Width = 360, Padding = new Padding(10), BackColor = _report.BackColor };
        var center = new Panel { Dock = DockStyle.Fill, Padding = new Padding(10) };
        var bottom = new Panel { Dock = DockStyle.Bottom, Height = 70, Padding = new Padding(0, 8, 0, 0) };

        int y = 12;
        Control Place(Control c, int height)
        {
            c.SetBounds(12, y, 266, height);
            left.Controls.Add(c);
            y += height + 8;
            return c;
        }

        Place(new Label { Text = "Тема, яку ти поясниш:", AutoSize = false }, 22);
        Place(_cmbTopic, 28);
        Place(_btnStart, 38);
        Place(_btnFinish, 38);
        Place(_btnControl, 38);
        Place(_lblStatus, 44);
        Place(new Label
        {
            AutoSize = false,
            ForeColor = Color.FromArgb(70, 70, 70),
            Font = new Font("Segoe UI", 8.5f),
            Text = "Як це працює\n" +
                   "Ти — вчитель, ШІ — учень Петрик. Він нічого не пояснює сам, лише перепитує " +
                   "й іноді помиляється — виправ його.\n\n" +
                   "Приватність\n" +
                   "Без реєстрації та імен. У ШІ (Google Gemini) передається лише текст твоїх реплік " +
                   "і назва теми. E-mail і телефони вирізаються автоматично. Історія не зберігається на диск.\n\n" +
                   "Точність\n" +
                   "Розбір звіряється з перевіреною карткою теми. Відповідь до задачі обчислює " +
                   "програма, а не ШІ."
        }, 300);

        var reportTitle = new Label { Text = "Розбір твого пояснення", Dock = DockStyle.Top, Height = 28, Font = new Font(Font, FontStyle.Bold) };
        _report.Dock = DockStyle.Fill;
        right.Controls.Add(_report);
        right.Controls.Add(reportTitle);

        _btnSend.Dock = DockStyle.Right;
        _btnSend.Width = 110;
        _txtInput.Dock = DockStyle.Fill;
        bottom.Controls.Add(_txtInput);
        bottom.Controls.Add(_btnSend);

        _chat.Dock = DockStyle.Fill;
        center.Controls.Add(_chat);
        center.Controls.Add(bottom);

        Controls.Add(center);
        Controls.Add(right);
        Controls.Add(left);
        center.BringToFront();
        _chat.BringToFront();
        _txtInput.BringToFront();
        _report.BringToFront();

        _report.Text = "Тут з'явиться розбір після уроку:\nякі ключові ідеї ти пояснив(-ла), а які пропустив(-ла).";
    }

    private void Say(string who, string text, Color color)
    {
        _chat.SelectionStart = _chat.TextLength;
        _chat.SelectionColor = color;
        _chat.SelectionFont = new Font(_chat.Font, FontStyle.Bold);
        _chat.AppendText(who + "\n");
        _chat.SelectionColor = Color.Black;
        _chat.SelectionFont = _chat.Font;
        _chat.AppendText(text.Trim() + "\n\n");
        _chat.ScrollToCaret();
    }

    private void Petryk(string text) => Say("Петрик (ШІ-учень)", text, Color.FromArgb(0, 110, 60));
    private void Tutor(string text) => Say("Підказка (ШІ)", text, Color.FromArgb(150, 90, 0));
    private void App(string text) => Say("Програма", text, Color.FromArgb(90, 90, 90));
    private void Me(string text) => Say("Ти", text, Color.FromArgb(0, 70, 160));

    private void SetBusy(bool busy, string status = "")
    {
        _busy = busy;
        _btnSend.Enabled = !busy && _mode != Mode.Idle;
        _txtInput.Enabled = _mode != Mode.Idle;
        _btnStart.Enabled = !busy;
        _btnFinish.Enabled = !busy && _mode == Mode.Teaching;
        _btnControl.Enabled = !busy && _mode != Mode.Idle;
        _lblStatus.Text = busy ? status : StatusText();
        if (!busy && _txtInput.Enabled) _txtInput.Focus();
    }

    private string StatusText() => _mode switch
    {
        Mode.Teaching => "Іде урок: пояснюй тему своїми словами.",
        Mode.Control => "Контрольна: введи число або попроси підказку.",
        _ => _ai == null ? "Немає ключа API (див. README)." : $"Модель: {_ai.Model}"
    };

    // ------------------------------------------------------------------ логіка

    private void InitAi()
    {
        var key = Env.Get("GEMINI_API_KEY");
        var model = Env.Get("GEMINI_MODEL") ?? "gemini-2.5-flash";
        if (key == null)
        {
            App("Не знайдено ключ GEMINI_API_KEY. Скопіюй файл .env.example у .env поруч із .sln, " +
                "встав туди свій ключ із Google AI Studio і перезапусти програму.");
            _btnStart.Enabled = false;
        }
        else
        {
            _ai = new GeminiClient(key, model);
            App("Обери тему й натисни «Почати урок». Твоє завдання — пояснити тему Петрикові так, щоб він зрозумів.");
        }
        _lblStatus.Text = StatusText();
    }

    private void StartLesson()
    {
        if (_ai == null || _busy) return;
        _card = Topics.All[_cmbTopic.SelectedIndex];
        _history.Clear();
        _studentTexts.Clear();
        _hintHistory.Clear();
        _task = null;
        _chat.Clear();
        _report.Text = "Розбір з'явиться після кнопки «Завершити урок».";
        _mode = Mode.Teaching;

        string opener = $"Привіт! Я Петрик, сьомий клас. Кажуть, ти розумієш тему «{_card.Title}», а я — зовсім ні. " +
                        "Поясни мені, будь ласка, з самого початку: про що вона взагалі?";
        _history.Add(new ChatTurn("user", $"Привіт, Петрику! Зараз я поясню тобі тему «{_card.Title}»."));
        _history.Add(new ChatTurn("model", opener));
        Petryk(opener);
        SetBusy(false);
    }

    private async Task SendAsync()
    {
        if (_ai == null || _busy || _mode == Mode.Idle) return;
        var text = _txtInput.Text.Trim();
        if (text.Length == 0) return;
        _txtInput.Clear();
        Me(text);

        if (_mode == Mode.Teaching) await TeachTurnAsync(text);
        else await ControlTurnAsync(text);
    }

    private async Task TeachTurnAsync(string text)
    {
        var safe = Guards.ScrubPersonalData(text);
        _history.Add(new ChatTurn("user", safe));
        SetBusy(true, "Петрик думає…");
        try
        {
            var reply = await _ai!.AskAsync(Prompts.Pupil(_card), _history, temperature: 0.8);
            _history.Add(new ChatTurn("model", reply));
            _studentTexts.Add(safe);
            Petryk(reply);
        }
        catch (Exception ex)
        {
            _history.RemoveAt(_history.Count - 1);
            App("Не вдалося отримати відповідь ШІ: " + ex.Message);
        }
        finally { SetBusy(false); }
    }

    private async Task FinishLessonAsync()
    {
        if (_ai == null || _busy) return;
        if (_studentTexts.Count < 2)
        {
            App("Поясни Петрикові ще трохи — для розбору потрібно щонайменше дві твої репліки.");
            return;
        }

        var transcript = string.Join("\n", _studentTexts.Select((t, i) => $"[{i + 1}] {t}"));
        SetBusy(true, "Звіряю пояснення з карткою теми…");
        try
        {
            var raw = await _ai.AskAsync(Prompts.Evaluator(_card),
                new[] { new ChatTurn("user", "Репліки учня:\n" + transcript) }, json: true, temperature: 0.1);
            ShowReport(ParseEvaluation(raw), transcript);
            App("Розбір готовий (праворуч). Можеш пояснити Петрикові пропущене ще раз або перейти до контрольної задачі.");
        }
        catch (Exception ex)
        {
            App("Не вдалося зробити розбір: " + ex.Message);
        }
        finally { SetBusy(false); }
    }

    private sealed class Evaluation
    {
        public List<int> Covered { get; set; } = new();
        public List<EvalError> Errors { get; set; } = new();
        public string Question { get; set; } = "";
    }

    private sealed class EvalError
    {
        public string Quote { get; set; } = "";
        public string Why { get; set; } = "";
    }

    private static Evaluation ParseEvaluation(string raw)
    {
        int a = raw.IndexOf('{'), b = raw.LastIndexOf('}');
        if (a < 0 || b <= a) throw new InvalidOperationException("ШІ повернув відповідь у неочікуваному форматі.");
        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        return JsonSerializer.Deserialize<Evaluation>(raw.Substring(a, b - a + 1), options)
               ?? throw new InvalidOperationException("Порожній розбір.");
    }

    private void ShowReport(Evaluation ev, string transcript)
    {
        var sb = new StringBuilder();
        var covered = ev.Covered.Where(i => i >= 0 && i < _card.KeyIdeas.Length).ToHashSet();

        sb.AppendLine($"Тема: {_card.Title}");
        sb.AppendLine($"Пояснено ключових ідей: {covered.Count} із {_card.KeyIdeas.Length}");
        sb.AppendLine();
        // Текст ідей береться з перевіреної картки, а не з відповіді моделі.
        for (int i = 0; i < _card.KeyIdeas.Length; i++)
        {
            if (covered.Contains(i)) sb.AppendLine("✔ " + _card.KeyIdeas[i]);
            else sb.AppendLine($"✘ Ідея №{i + 1} — ще не прозвучала. Згадай сам(-а), перш ніж дивитися в підручник.");
            sb.AppendLine();
        }

        // Показуємо лише ті зауваження, де цитата справді є в тексті учня.
        var real = ev.Errors.Where(e => Guards.IsRealQuote(e.Quote, transcript)).ToList();
        if (real.Count > 0)
        {
            sb.AppendLine("Місця, які варто перевірити:");
            foreach (var e in real)
            {
                sb.AppendLine($"• «{e.Quote.Trim()}»");
                sb.AppendLine("  " + e.Why.Trim());
            }
            sb.AppendLine();
        }

        if (!string.IsNullOrWhiteSpace(ev.Question))
        {
            sb.AppendLine("Запитання для самоперевірки:");
            sb.AppendLine(ev.Question.Trim());
            sb.AppendLine();
        }

        sb.AppendLine("Де перевірити: " + _card.Source);
        sb.AppendLine();
        sb.AppendLine("Зауваження сформував ШІ, він може помилятися — звір із підручником або запитай учителя.");
        _report.Text = sb.ToString();
    }

    private void StartControlTask()
    {
        if (_ai == null || _busy || _mode == Mode.Idle) return;
        _task = _card.MakeTask(_rnd);
        _hintHistory.Clear();
        _mode = Mode.Control;
        App("Контрольна задача. Розв'яжи сам(-а) і введи лише число. Якщо застряг(-ла) — напиши, на чому саме, і отримаєш навідне запитання.\n\n" + _task.Text);
        SetBusy(false);
    }

    private async Task ControlTurnAsync(string text)
    {
        if (_task == null) return;

        // 1) Учень увів число — перевіряє КОД, ШІ не залучається.
        var answer = Guards.TryParseAnswer(text);
        if (answer != null)
        {
            if (answer.Value == _task.Answer)
                App("Правильно! Це перевірила програма обчисленням. Тепер поясни Петрикові одним реченням, чому вийшло саме так, " +
                    "або натисни «Контрольна задача» — отримаєш нову з іншими числами.");
            else
                App("Поки що ні. Відповіді я не скажу, але подумай над цим:\n" + _task.CannedHint);
            return;
        }

        // 2) Інакше це запитання — ШІ дає навідну підказку, а код стежить, щоб відповідь не «витекла».
        _hintHistory.Add(new ChatTurn("user", Guards.ScrubPersonalData(text)));
        SetBusy(true, "Готую підказку…");
        try
        {
            var reply = await _ai!.AskAsync(Prompts.Hint(_card, _task), _hintHistory, temperature: 0.4);
            if (Guards.LeaksAnswer(reply, _task.Forbidden))
                reply = _task.CannedHint; // фільтр спрацював: замінюємо безпечною підказкою
            _hintHistory.Add(new ChatTurn("model", reply));
            Tutor(reply);
        }
        catch (Exception ex)
        {
            _hintHistory.RemoveAt(_hintHistory.Count - 1);
            App("ШІ зараз недоступний (" + ex.Message + ").\nПідказка від програми: " + _task.CannedHint);
        }
        finally { SetBusy(false); }
    }
}
