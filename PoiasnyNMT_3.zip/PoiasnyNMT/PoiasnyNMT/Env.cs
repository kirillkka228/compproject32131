namespace PoiasnyNMT;

/// <summary>
/// Читає налаштування зі змінних середовища або з файлу .env
/// (шукає .env у поточній теці та до 5 рівнів вище — щоб працювало при запуску з bin\Debug).
/// Ключ API ніколи не зберігається в коді.
/// </summary>
public static class Env
{
    private static readonly Dictionary<string, string> FileValues = Load();

    public static string? Get(string name)
    {
        var v = Environment.GetEnvironmentVariable(name);
        if (!string.IsNullOrWhiteSpace(v)) return v.Trim();
        return FileValues.TryGetValue(name, out var f) && f.Length > 0 ? f : null;
    }

    private static Dictionary<string, string> Load()
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        for (int i = 0; i < 6 && dir != null; i++, dir = dir.Parent)
        {
            var path = Path.Combine(dir.FullName, ".env");
            if (!File.Exists(path)) continue;
            foreach (var raw in File.ReadAllLines(path))
            {
                var line = raw.Trim();
                if (line.Length == 0 || line.StartsWith('#')) continue;
                int eq = line.IndexOf('=');
                if (eq <= 0) continue;
                result[line[..eq].Trim()] = line[(eq + 1)..].Trim().Trim('"');
            }
            break;
        }
        return result;
    }
}
