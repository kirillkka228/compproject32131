using System.Globalization;
using System.Text.RegularExpressions;

namespace PoiasnyNMT;


public static class Guards
{
    private static readonly Regex NumberRx = new(@"-?\d+(?:[.,]\d+)?", RegexOptions.Compiled);
    private static readonly Regex AnswerRx = new(
        @"^\s*(?:[xхXХ]\s*=\s*)?(-?\d+(?:[.,]\d+)?)\s*(?:грн|см)?\.?\s*$", RegexOptions.Compiled);
    private static readonly Regex EmailRx = new(@"[\w.+-]+@[\w-]+\.[\w.-]+", RegexOptions.Compiled);
    private static readonly Regex PhoneRx = new(@"\+?\d[\d\s\-()]{8,}\d", RegexOptions.Compiled);


    public static string ScrubPersonalData(string text)
    {
        text = EmailRx.Replace(text, "[приховано]");
        return PhoneRx.Replace(text, "[приховано]");
    }

    public static decimal? TryParseAnswer(string input)
    {
        var m = AnswerRx.Match(Normalize(input));
        return m.Success ? ParseDecimal(m.Groups[1].Value) : null;
    }

    public static bool LeaksAnswer(string reply, decimal[] forbidden)
    {
        foreach (Match m in NumberRx.Matches(Normalize(reply)))
        {
            var v = ParseDecimal(m.Value);
            if (v == null) continue;
            if (forbidden.Any(f => f == v.Value || f == -v.Value)) return true;
        }
        return false;
    }


    public static bool IsRealQuote(string quote, string studentText)
    {
        var q = Squash(quote);
        return q.Length >= 3 && Squash(studentText).Contains(q);
    }

    private static string Squash(string s) =>
        Regex.Replace(s.ToLowerInvariant(), @"\s+", " ").Trim(' ', '"', '«', '»', '.', '…');

    private static string Normalize(string s) => s.Replace('−', '-').Replace('–', '-');

    private static decimal? ParseDecimal(string s) =>
        decimal.TryParse(s.Replace(',', '.'), NumberStyles.Number, CultureInfo.InvariantCulture, out var d) ? d : null;
}
