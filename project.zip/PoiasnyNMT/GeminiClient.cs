using System.Text;
using System.Text.Json;

namespace PoiasnyNMT;

/// <summary>Одна репліка діалогу. Role: "user" (учень) або "model" (ШІ).</summary>
public record ChatTurn(string Role, string Text);

/// <summary>
/// Мінімальний клієнт Google Gemini API (REST, generateContent).
/// Якщо основна модель перевантажена, сам повторює запит і за потреби
/// переходить на іншу доступну ключу модель сімейства Flash.
/// </summary>
public sealed class GeminiClient
{
    private const string BaseUrl = "https://generativelanguage.googleapis.com/v1beta/";
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(60) };
    private static readonly string[] NotChatModels = { "image", "tts", "audio", "live", "embedding", "robotics", "computer-use" };

    private readonly string _apiKey;
    private string _model;
    private List<string>? _alternatives;

    public GeminiClient(string apiKey, string model)
    {
        _apiKey = apiKey;
        _model = model;
    }

    /// <summary>Модель, яка зараз використовується (може змінитися після перемикання).</summary>
    public string Model => _model;

    public async Task<string> AskAsync(string systemPrompt, IEnumerable<ChatTurn> history,
                                       bool json = false, double temperature = 0.7)
    {
        var body = new Dictionary<string, object>
        {
            ["systemInstruction"] = new { parts = new[] { new { text = systemPrompt } } },
            ["contents"] = history.Select(t => new
            {
                role = t.Role,
                parts = new[] { new { text = t.Text } }
            }).ToArray(),
            ["generationConfig"] = json
                ? new Dictionary<string, object> { ["temperature"] = temperature, ["responseMimeType"] = "application/json" }
                : new Dictionary<string, object> { ["temperature"] = temperature }
        };
        var payload = JsonSerializer.Serialize(body);

        // 1) Основна модель: до трьох спроб із паузами.
        var result = await TryModelAsync(_model, payload, new[] { 1500, 3000 });

        // 2) Якщо вона перевантажена або вичерпано ліміт — пробуємо інші моделі Flash.
        if (!result.Ok && IsTemporary(result.Code))
        {
            foreach (var alt in await GetAlternativesAsync())
            {
                var r = await TryModelAsync(alt, payload, Array.Empty<int>());
                if (!r.Ok) continue;
                _model = alt; // надалі одразу звертаємось до робочої моделі
                result = r;
                break;
            }
        }

        if (!result.Ok)
        {
            var reason = ExtractMessage(result.Text);
            throw new InvalidOperationException(result.Code switch
            {
                429 => "вичерпано ліміт запитів для цього ключа (429). " + reason,
                500 or 503 => "сервери моделі зараз перевантажені (" + result.Code + "), запасні моделі теж недоступні. Спробуй ще раз за хвилину.",
                _ => $"Gemini API повернув помилку {result.Code}: {reason}"
            });
        }

        using var doc = JsonDocument.Parse(result.Text);
        if (!doc.RootElement.TryGetProperty("candidates", out var cands) || cands.GetArrayLength() == 0)
            throw new InvalidOperationException("Модель не повернула відповіді (можливо, запит заблоковано фільтром).");

        var sb = new StringBuilder();
        if (cands[0].TryGetProperty("content", out var content) &&
            content.TryGetProperty("parts", out var parts))
        {
            foreach (var p in parts.EnumerateArray())
                if (p.TryGetProperty("text", out var t)) sb.Append(t.GetString());
        }
        if (sb.Length == 0)
            throw new InvalidOperationException("Модель повернула порожню відповідь.");
        return sb.ToString().Trim();
    }

    private static bool IsTemporary(int code) => code == 429 || code == 500 || code == 503;

    private async Task<(bool Ok, int Code, string Text)> TryModelAsync(string model, string payload, int[] retryDelaysMs)
    {
        for (int attempt = 0; ; attempt++)
        {
            using var req = new HttpRequestMessage(HttpMethod.Post, $"{BaseUrl}models/{model}:generateContent");
            req.Headers.Add("x-goog-api-key", _apiKey);
            req.Content = new StringContent(payload, Encoding.UTF8, "application/json");

            using var resp = await Http.SendAsync(req);
            var text = await resp.Content.ReadAsStringAsync();
            int code = (int)resp.StatusCode;
            if (resp.IsSuccessStatusCode) return (true, code, text);
            if (!IsTemporary(code) || attempt >= retryDelaysMs.Length) return (false, code, text);
            await Task.Delay(retryDelaysMs[attempt]);
        }
    }

    /// <summary>Запитує в Google список моделей, доступних ключу, і лишає текстові Flash-моделі.</summary>
    private async Task<List<string>> GetAlternativesAsync()
    {
        if (_alternatives != null) return _alternatives.Where(m => m != _model).ToList();
        var list = new List<string>();
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, BaseUrl + "models?pageSize=200");
            req.Headers.Add("x-goog-api-key", _apiKey);
            using var resp = await Http.SendAsync(req);
            if (resp.IsSuccessStatusCode)
            {
                using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync());
                if (doc.RootElement.TryGetProperty("models", out var models))
                {
                    foreach (var m in models.EnumerateArray())
                    {
                        var name = (m.TryGetProperty("name", out var n) ? n.GetString() : null) ?? "";
                        if (name.StartsWith("models/")) name = name["models/".Length..];
                        bool canGenerate = m.TryGetProperty("supportedGenerationMethods", out var methods) &&
                                           methods.EnumerateArray().Any(x => x.GetString() == "generateContent");
                        if (!canGenerate || !name.Contains("flash")) continue;
                        if (NotChatModels.Any(w => name.Contains(w))) continue;
                        list.Add(name);
                    }
                }
            }
        }
        catch
        {
            // немає списку — просто не буде запасних моделей
        }
        // Новіші моделі зазвичай стоять у кінці списку — пробуємо їх першими.
        list.Reverse();
        _alternatives = list.Take(6).ToList();
        return _alternatives.Where(m => m != _model).ToList();
    }

    private static string ExtractMessage(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("error", out var e) && e.TryGetProperty("message", out var m))
                return Shorten(m.GetString() ?? "");
        }
        catch { }
        return Shorten(json);
    }

    private static string Shorten(string s) => s.Length <= 300 ? s : s[..300] + "…";
}
