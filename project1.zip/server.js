// «Поясни Петрику» — маленький сервер без сторонніх залежностей (потрібен лише Node.js 18+).
// Він роздає сторінку з папки public і ходить до ШІ. Ключ API живе тільки тут, у браузер не потрапляє.
// Промпти, перевірка відповідей і фільтр «витоку відповіді» теж працюють на сервері,
// тому обійти їх через браузер не вийде.

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { exec } = require('child_process');

const { TOPICS } = require('./topics');
const prompts = require('./prompts');
const guards = require('./guards');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');

// ---------------------------------------------------------------- налаштування (.env)

function loadEnvFile() {
  // Приймаємо .env, .env.txt тощо (Windows любить дописувати .txt), крім .env.example
  const file = fs.readdirSync(ROOT)
    .filter((f) => f.startsWith('.env') && !f.toLowerCase().includes('example'))
    .sort((a, b) => a.length - b.length)[0];
  const values = {};
  if (!file) return values;
  for (const raw of fs.readFileSync(path.join(ROOT, file), 'utf8').replace(/^﻿/, '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq <= 0) continue;
    values[line.slice(0, eq).trim()] = line.slice(eq + 1).trim().replace(/^"|"$/g, '');
  }
  return values;
}

const fileEnv = loadEnvFile();
const env = (name) => (process.env[name] || fileEnv[name] || '').trim();

const config = {
  apiKey: env('GROQ_API_KEY'),
  model: env('GROQ_MODEL') || 'llama-3.3-70b-versatile',
  baseUrl: (env('GROQ_BASE_URL') || 'https://api.groq.com/openai/v1').replace(/\/+$/, ''),
  port: Number(env('PORT')) || 3000,
};

// ---------------------------------------------------------------- виклик ШІ (Groq, OpenAI-сумісний API)

class AiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const isTemporary = (s) => s === 429 || s >= 500;
const NOT_CHAT = /whisper|guard|tts|speech|embed|orpheus|allam|compound|safeguard|vision|audio/i;
let alternatives = null;

async function callModel(model, messages, { json, temperature }) {
  const body = { model, messages, temperature };
  if (json) body.response_format = { type: 'json_object' };
  let res;
  try {
    res = await fetch(`${config.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${config.apiKey}` },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(45000),
    });
  } catch (e) {
    return { ok: false, status: 0, message: 'немає зв\'язку із сервером ШІ (перевір інтернет)' };
  }
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch { /* не JSON */ }
  if (!res.ok) {
    return { ok: false, status: res.status, message: (data && data.error && data.error.message) || text.slice(0, 300) };
  }
  const content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  if (!content || !content.trim()) return { ok: false, status: 502, message: 'модель повернула порожню відповідь' };
  return { ok: true, status: 200, content: content.trim() };
}

async function tryModel(model, messages, opts, delays) {
  for (let attempt = 0; ; attempt++) {
    let r = await callModel(model, messages, opts);
    // деякі моделі не вміють JSON-режим — тоді просимо звичайний текст і дістаємо JSON самі
    if (!r.ok && r.status === 400 && opts.json && /json|response_format/i.test(r.message)) {
      r = await callModel(model, messages, { ...opts, json: false });
    }
    if (r.ok || !isTemporary(r.status) || attempt >= delays.length) return r;
    await sleep(delays[attempt]);
  }
}

async function getAlternatives() {
  if (!alternatives) {
    alternatives = [];
    try {
      const res = await fetch(`${config.baseUrl}/models`, {
        headers: { Authorization: `Bearer ${config.apiKey}` },
        signal: AbortSignal.timeout(15000),
      });
      if (res.ok) {
        const data = await res.json();
        const score = (id) => (/70b/.test(id) ? 0 : /versatile|120b|kimi|qwen/.test(id) ? 1 : /instant|8b|20b/.test(id) ? 3 : 2);
        alternatives = (data.data || [])
          .map((m) => m.id)
          .filter((id) => id && !NOT_CHAT.test(id))
          .sort((a, b) => score(a) - score(b))
          .slice(0, 6);
      }
    } catch { /* без списку просто не буде запасних моделей */ }
  }
  return alternatives.filter((m) => m !== config.model);
}

/** Питає модель; якщо вона перевантажена або знята — сам переходить на іншу доступну. */
async function askAi(messages, opts = {}) {
  const options = { json: false, temperature: 0.7, ...opts };
  if (!config.apiKey) throw new AiError('Не налаштовано ключ API.', 503);

  let result = await tryModel(config.model, messages, options, [1200, 2500]);
  const modelGone = !result.ok && (result.status === 404 || (result.status === 400 && /model/i.test(result.message)));

  if (!result.ok && (isTemporary(result.status) || modelGone)) {
    for (const alt of await getAlternatives()) {
      const r = await tryModel(alt, messages, options, []);
      if (!r.ok) continue;
      console.log(`[ШІ] модель ${config.model} недоступна, переходжу на ${alt}`);
      config.model = alt;
      result = r;
      break;
    }
  }

  if (!result.ok) {
    const s = result.status;
    if (s === 401 || s === 403) throw new AiError('Ключ API недійсний або відкликаний. Створи новий на console.groq.com/keys.', 401);
    if (s === 429) throw new AiError('Вичерпано ліміт запитів для ключа. Зачекай хвилину й спробуй ще раз.', 429);
    if (s === 0) throw new AiError(result.message, 502);
    if (s >= 500) throw new AiError('Сервери ШІ зараз перевантажені. Спробуй ще раз за хвилину.', 503);
    throw new AiError(`ШІ повернув помилку ${s}: ${result.message}`, 502);
  }
  return result.content;
}

// ---------------------------------------------------------------- допоміжне

const tasks = new Map(); // taskId -> { topicId, text, answer, forbidden, hint, created }

function rememberTask(topic) {
  // прибираємо старі задачі, щоб пам'ять не росла
  const now = Date.now();
  for (const [id, t] of tasks) if (now - t.created > 3 * 3600 * 1000) tasks.delete(id);
  const id = crypto.randomUUID();
  tasks.set(id, { topicId: topic.id, ...topic.makeTask(), created: now });
  return id;
}

const findTopic = (id) => TOPICS.find((t) => t.id === id);

/** Історію діалогу надсилає браузер; тут її обрізаємо, чистимо і приводимо до формату API. */
function cleanHistory(history) {
  if (!Array.isArray(history)) return [];
  return history
    .filter((m) => m && typeof m.text === 'string' && m.text.trim())
    .slice(-30)
    .map((m) => ({
      role: m.role === 'ai' ? 'assistant' : 'user',
      content: m.role === 'ai' ? m.text.slice(0, 2000) : guards.scrubPersonalData(m.text.slice(0, 2000)),
    }));
}

function send(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 200 * 1024) { reject(new AiError('Завеликий запит.', 413)); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch { reject(new AiError('Некоректний запит.', 400)); }
    });
    req.on('error', reject);
  });
}

function parseEvaluation(raw) {
  const a = raw.indexOf('{'), b = raw.lastIndexOf('}');
  if (a < 0 || b <= a) throw new AiError('ШІ повернув розбір у неочікуваному форматі. Спробуй ще раз.', 502);
  try { return JSON.parse(raw.slice(a, b + 1)); }
  catch { throw new AiError('ШІ повернув розбір у неочікуваному форматі. Спробуй ще раз.', 502); }
}

// ---------------------------------------------------------------- API

const api = {
  'GET /api/status': async () => ({
    configured: Boolean(config.apiKey),
    model: config.model,
    topics: TOPICS.map((t) => ({ id: t.id, icon: t.icon, title: t.title, teaser: t.teaser, ideas: t.keyIdeas.length })),
  }),

  // Перше налаштування: ключ вводиться на сторінці й записується у .env на цьому комп'ютері.
  'POST /api/setup': async (body, req) => {
    const local = ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
    if (!local) throw new AiError('Налаштування доступне лише з цього комп\'ютера.', 403);
    if (config.apiKey) throw new AiError('Ключ уже налаштовано. Щоб змінити його, відредагуй файл .env і перезапусти сервер.', 409);
    const key = String(body.key || '').trim();
    if (key.length < 20 || /\s/.test(key)) throw new AiError('Це не схоже на ключ API.', 400);

    config.apiKey = key;
    const check = await callModel(config.model, [{ role: 'user', content: 'Скажи «ок».' }], { json: false, temperature: 0 });
    if (!check.ok && (check.status === 401 || check.status === 403)) {
      config.apiKey = '';
      throw new AiError('Сервіс не прийняв цей ключ. Перевір, що скопійовано його повністю.', 400);
    }
    fs.writeFileSync(path.join(ROOT, '.env'), `GROQ_API_KEY=${key}\n`, 'utf8');
    return { ok: true };
  },

  // Урок: учень пояснює, Петрик перепитує.
  'POST /api/chat': async (body) => {
    const topic = findTopic(body.topicId);
    if (!topic) throw new AiError('Невідома тема.', 400);
    const history = cleanHistory(body.history);
    if (!history.length || history[history.length - 1].role !== 'user') throw new AiError('Порожнє повідомлення.', 400);
    const reply = await askAi([{ role: 'system', content: prompts.pupil(topic) }, ...history], { temperature: 0.8 });
    return { reply };
  },

  // Розбір: ШІ лише вказує номери ідей і цитати; тексти ідей беруться з перевіреної картки.
  'POST /api/evaluate': async (body) => {
    const topic = findTopic(body.topicId);
    if (!topic) throw new AiError('Невідома тема.', 400);
    const texts = (Array.isArray(body.studentTexts) ? body.studentTexts : [])
      .filter((t) => typeof t === 'string' && t.trim())
      .slice(-30)
      .map((t) => guards.scrubPersonalData(t.slice(0, 2000)));
    if (texts.length < 2) throw new AiError('Для розбору потрібно щонайменше дві твої репліки.', 400);

    const transcript = texts.map((t, i) => `[${i + 1}] ${t}`).join('\n');
    const raw = await askAi(
      [{ role: 'system', content: prompts.evaluator(topic) }, { role: 'user', content: `Репліки учня:\n${transcript}` }],
      { json: true, temperature: 0.1 },
    );
    const ev = parseEvaluation(raw);

    const covered = new Set((Array.isArray(ev.covered) ? ev.covered : [])
      .map(Number).filter((i) => Number.isInteger(i) && i >= 0 && i < topic.keyIdeas.length));
    // показуємо лише ті зауваження, де цитата справді є в тексті учня
    const errors = (Array.isArray(ev.errors) ? ev.errors : [])
      .filter((e) => e && typeof e.quote === 'string' && typeof e.why === 'string' && guards.isRealQuote(e.quote, transcript))
      .slice(0, 5)
      .map((e) => ({ quote: e.quote.trim(), why: e.why.trim() }));

    return {
      total: topic.keyIdeas.length,
      // пропущені ідеї не розкриваємо — учень має пригадати їх сам
      ideas: topic.keyIdeas.map((text, i) => ({ covered: covered.has(i), text: covered.has(i) ? text : null })),
      errors,
      question: typeof ev.question === 'string' ? ev.question.trim() : '',
      source: topic.source,
    };
  },

  // Контрольна задача: числа й відповідь генерує код.
  'POST /api/task': async (body) => {
    const topic = findTopic(body.topicId);
    if (!topic) throw new AiError('Невідома тема.', 400);
    const taskId = rememberTask(topic);
    return { taskId, text: tasks.get(taskId).text };
  },

  // Перевірка відповіді — тільки кодом, без ШІ. Правильну відповідь сервер не повертає ніколи.
  'POST /api/answer': async (body) => {
    const task = tasks.get(body.taskId);
    if (!task) throw new AiError('Задачу не знайдено — візьми нову.', 404);
    const value = guards.parseAnswer(String(body.answer || ''));
    if (value === null) return { isNumber: false };
    const correct = Math.abs(value - task.answer) < 1e-9;
    return { isNumber: true, correct, hint: correct ? null : task.hint };
  },

  // Підказка від ШІ; якщо в ній трапилась відповідь — замінюємо безпечною, написаною заздалегідь.
  'POST /api/hint': async (body) => {
    const task = tasks.get(body.taskId);
    if (!task) throw new AiError('Задачу не знайдено — візьми нову.', 404);
    const topic = findTopic(task.topicId);
    const history = cleanHistory(body.history);
    if (!history.length) throw new AiError('Порожнє повідомлення.', 400);
    try {
      let reply = await askAi([{ role: 'system', content: prompts.hint(topic, task.text) }, ...history], { temperature: 0.4 });
      const filtered = guards.leaksAnswer(reply, task.forbidden);
      if (filtered) reply = task.hint;
      return { reply, filtered };
    } catch (e) {
      // ШІ недоступний — підказка від програми все одно є
      return { reply: task.hint, filtered: false, offline: true };
    }
  },
};

// ---------------------------------------------------------------- HTTP-сервер

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

function serveStatic(req, res) {
  let rel = decodeURIComponent(req.url.split('?')[0]);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); res.end(); return; }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Не знайдено'); return; }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const route = `${req.method} ${req.url.split('?')[0]}`;
  const handler = api[route];
  if (!handler) {
    if (req.method === 'GET') return serveStatic(req, res);
    return send(res, 404, { error: 'Не знайдено' });
  }
  try {
    const body = req.method === 'POST' ? await readJson(req) : {};
    send(res, 200, await handler(body, req));
  } catch (e) {
    if (!(e instanceof AiError)) console.error(e);
    send(res, e instanceof AiError ? e.status : 500, { error: e instanceof AiError ? e.message : 'Внутрішня помилка сервера.' });
  }
});

if (require.main === module) {
  server.listen(config.port, () => {
    const url = `http://localhost:${config.port}`;
    console.log(`\n  Поясни Петрику працює: ${url}`);
    console.log(config.apiKey ? `  Модель: ${config.model}` : '  Ключ API ще не задано — сторінка попросить його ввести.');
    console.log('  Щоб зупинити, натисни Ctrl+C.\n');
    if (!env('NO_OPEN')) {
      const cmd = process.platform === 'win32' ? `start "" "${url}"` : process.platform === 'darwin' ? `open "${url}"` : `xdg-open "${url}"`;
      exec(cmd, () => {});
    }
  });
  server.on('error', (e) => {
    console.error(e.code === 'EADDRINUSE'
      ? `Порт ${config.port} зайнятий. Закрий інше вікно сервера або задай PORT=3001 у .env.`
      : e.message);
    process.exit(1);
  });
}

module.exports = { server, config };
