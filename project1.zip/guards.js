// Перевірки, які виконує КОД, а не ШІ: приватність, відповідь, витік відповіді, цитати.

const NUMBER_RX = /-?\d+(?:[.,]\d+)?/g;
const ANSWER_RX = /^\s*(?:[xх]\s*=\s*)?(-?\d+(?:[.,]\d+)?)\s*(?:грн|см)?\.?\s*$/i;
const EMAIL_RX = /[\w.+-]+@[\w-]+\.[\w.-]+/g;
const PHONE_RX = /\+?\d[\d\s\-()]{8,}\d/g;

const normalize = (s) => s.replace(/[−–]/g, '-');
const toNumber = (s) => {
  const n = Number(s.replace(',', '.'));
  return Number.isFinite(n) ? n : null;
};

/** Прибирає e-mail і телефони перед відправкою тексту в ШІ. */
function scrubPersonalData(text) {
  return text.replace(EMAIL_RX, '[приховано]').replace(PHONE_RX, '[приховано]');
}

/** Якщо учень увів саме число — повертає його; інакше null (це запитання, а не відповідь). */
function parseAnswer(input) {
  const m = ANSWER_RX.exec(normalize(input));
  return m ? toNumber(m[1]) : null;
}

/** Чи містить репліка ШІ число, яке не можна видавати (відповідь задачі). */
function leaksAnswer(reply, forbidden) {
  const found = normalize(reply).match(NUMBER_RX) || [];
  return found.some((s) => {
    const v = toNumber(s);
    return v !== null && forbidden.some((f) => Math.abs(f - v) < 1e-9 || Math.abs(f + v) < 1e-9);
  });
}

const squash = (s) => s.toLowerCase().replace(/\s+/g, ' ').replace(/^[\s"«».…]+|[\s"«».…]+$/g, '');

/** Чи справді учень таке писав (захист від вигаданих моделлю «цитат»). */
function isRealQuote(quote, studentText) {
  const q = squash(quote);
  return q.length >= 3 && squash(studentText).includes(q);
}

module.exports = { scrubPersonalData, parseAnswer, leaksAnswer, isRealQuote };
